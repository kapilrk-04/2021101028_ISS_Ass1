#!/bin/bash
awk 'NF' quotes.txt > 1a.txt
awk '!a[$0]++' quotes.txt > 1b.txt