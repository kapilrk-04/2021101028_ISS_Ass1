#!/bin/bash

#3a
read -p "Enter filename:" file
echo -n "Size of file in bytes:"
wc -c < $file

#3b
read -p "Enter filename:" file
echo -n "No.of lines:"
wc -l < $file

#3c
read -p "Enter filename:" file
echo -n "No.of words:"
wc -w < $file 

#3d
read -p "Enter filename:" file
let index=1
while read line
do
        echo -n "Line No:$index"
        let index++
        echo -n "- Count of Words:"
        wc -w <<< "$line"
done < $file

#3e
read -p "Enter filename:" file
grep -wo '[[:alnum:]]\+' $file | sort | uniq -cd | awk '{print "Word:",$2," - Count of repetition:",$1}'