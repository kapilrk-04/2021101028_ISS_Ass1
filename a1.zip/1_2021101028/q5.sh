#!/bin/bash

#5a
read -p "Enter the string:" str
length=${#str}

for ((i = $length - 1; i >= 0; i--))
do
	echo -n "${str:$i:1}"
done

#5b
read -p "Enter the string:" str
length=${#str}

for ((i = $length - 1; i >= 0; i--))
do
        echo -n "${str:$i:1}" | tr '[a-z]' '[b-za]' | tr '[A-Z]' '[B-ZA]'
done

#5c
read -p "Enter the string:" str
length=${#str}
let half=$length/2
for ((i = $half - 1; i >= 0; i--))
do
        echo -n "${str:$i:1}"
done
for ((j = $half; j < $length; j++))
do
	echo -n "${str:$j:1}"
done