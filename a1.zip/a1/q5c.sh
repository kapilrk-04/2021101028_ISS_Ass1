#!/bin/bash
read -p "Enter the string:" str
length=${#str}
let half=$length/2
for ((i = $half - 1; i >= 0; i--))
do
        echo -n "${str:$i:1}"
done
for ((j = $half; j < $length; j++))
do
	echo -n "${str:$j:1}"
done
