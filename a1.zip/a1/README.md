## NOTES

### Q2

Output format:
```
<author name>
once said: <quote>
```

### Q3

I/O format:

#### (a)
```
Enter filename: <filename>
Size of file in bytes: <size>
```
#### (b)
```
Enter filename: <filename>
No.of lines: <output>
```
#### (c)
```
Enter filename: <filename>
No.of words: <output>
```
#### (d)
```
Enter filename: <filename>
<output>
```
#### (e)
```
Enter filename: <filename>
<output>
```

### Q4

I/O Format:
```
Enter array: <array here>
Original array: <input array>
Sorted array: <sorted array>
```

### Q5

I/O format for all 3 questions:

```
Enter the string: <String>
<output>
```








