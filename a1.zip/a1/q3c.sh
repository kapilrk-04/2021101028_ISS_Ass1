#!/bin/bash
read -p "Enter filename:" file
echo -n "No.of words:"
wc -w < $file  

