awk 'NF' quotes.txt > 1a.txt
