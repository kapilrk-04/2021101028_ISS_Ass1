#!/bin/bash
read -p "Enter filename:" file
grep -wo '[[:alnum:]]\+' $file | sort | uniq -cd | awk '{print "Word:",$2," - Count of repetition:",$1}'

