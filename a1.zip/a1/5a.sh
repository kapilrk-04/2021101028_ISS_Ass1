#!/bin/bash
read -p "Enter the string:" str
length=${#str}

for ((i = $length - 1; i >= 0; i--))
do
	echo -n "${str:$i:1}"
done
