#!/bin/bash
grep -wo '[[:alnum:]]\+' quotes.txt | sort | uniq -cd | awk '{print "Word:",$2," - Count of repetition:",$1}'

