#!/bin/bash
awk 'NF' quotes.txt > 1a.txt
file="1a.txt"
while read line
do
	echo -e -n $line | cut -d '~' -f 2 
	echo -n "once said: "
	echo -e -n $line | cut -d '~' -f 1
done <$file

