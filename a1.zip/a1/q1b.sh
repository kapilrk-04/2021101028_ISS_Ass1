awk '!a[$0]++' quotes.txt > 1b.txt
