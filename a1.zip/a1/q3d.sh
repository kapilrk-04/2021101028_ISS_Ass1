#!/bin/bash
read -p "Enter filename:" file
let index=1
while read line
do
        echo -n "Line No:$index"
        let index++
        echo -n "- Count of Words:"
        wc -w <<< "$line"
done < $file
