#!/bin/bash
read -p "Enter filename:" file
echo -n "Size of file in bytes:"
wc -c < $file  

